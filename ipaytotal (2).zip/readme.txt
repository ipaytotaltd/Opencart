Installation:
---------------
Installable file name is  "ipaytotal.ocmod.zip"

1. Please Go to Extensions -> Extension Installer
2. Upload "ipaytotal.ocmod.zip" and click on continue.
3. Now install from admin -> Extensions -> Filter by Payment -> iPayTotal