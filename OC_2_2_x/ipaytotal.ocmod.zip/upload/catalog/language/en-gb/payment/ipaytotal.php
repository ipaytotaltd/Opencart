<?php
// Text
$_['text_title'] = 'iPayTotal';
$_['text_credit_card']     = 'Credit Card Details';

// Entry
$_['entry_cc_select']  = '-Select-';
$_['entry_cc_type']  = 'Card Type';
$_['entry_cc_owner']  = 'Card Owner Name';
$_['entry_cc_number']  = 'Card Number';
$_['entry_cc_expire_date'] = 'Card Expiry Date';
$_['entry_cc_cvv2']   = 'Card Security Code (CVV2)';
$_['entry_cc_amex'] = 'Amex';
$_['entry_cc_visa'] = 'Visa';
$_['entry_cc_master'] = 'Mastercard';
$_['entry_cc_discover'] = 'Discover';

$_['success_comment'] = 'Payment Processed by iPayTotal (#%s)';

//Error
$_['error_payment_failed'] = 'Sorry, Payment was not processed successfully.';
$_['error_cc_name'] = 'Please Enter Card Owner Name';
$_['error_cc_type'] = 'Select Your Card Type';
$_['error_cc_number'] = 'Please Enter Card Number';
$_['error_cc_expire'] = 'Please Select Expiry Date';
$_['error_cc_cvv'] = 'Please Enter Card CVV2';
?>