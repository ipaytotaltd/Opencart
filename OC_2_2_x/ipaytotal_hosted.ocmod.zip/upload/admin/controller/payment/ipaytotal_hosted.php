<?php 
class ControllerPaymentIpaytotalHosted extends Controller {
    private $error = array();
    private $prefix;
    private $extensions_url;
    private $_token;
    private $path = 'payment/ipaytotal_hosted';
    public function __construct($registry) {
        parent::__construct($registry);
        $this->prefix = VERSION >= '3.0.0.0' ? 'payment_' : '';
        $this->_token = VERSION >= '3.0.0.0' ? 'user_token=' . $this->session->data['user_token'] : 'token=' . $this->session->data['token'];

        if (VERSION >= '3.0.0.0'){
            $this->extensions_url = $this->url->link('marketplace/extension', $this->_token . '&type=payment', true);
        } else if (VERSION >= '2.3.0.0') {
            $this->extensions_url = $this->url->link('extension/extension', $this->_token . '&type=payment', true);
        } else {
            $this->extensions_url =$this->url->link('extension' . '/payment', $this->_token, true);
        }
    }
    private function _view($route, $data = array()) {
        $tpl =  VERSION < '2.2.0.0' ? '.tpl' : '';
        return $this->load->view($route . $tpl, $data);
    }
    public function index() {
        $this->language->load($this->path);
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('setting/setting');
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            if (VERSION >= '3.0.0.0') {
                foreach ($this->request->post as $key => $value) {
                    $this->request->post[$this->prefix . $key] = $value;
                }
            }
            $this->model_setting_setting->editSetting($this->prefix . 'ipaytotal', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->extensions_url);
        }

        $data['text_edit'] = $this->language->get('text_edit');
        $data['heading_title'] = $this->language->get('heading_title');
        $data['help_total'] = $this->language->get('help_total');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_all_zones'] = $this->language->get('text_all_zones');
        $data['entry_api_key'] = $this->language->get('entry_api_key');
        $data['user_token'] =$this->session->data['user_token'];
        $data['entry_total'] = $this->language->get('entry_total'); 
        $data['entry_order_status'] = $this->language->get('entry_order_status');
        $data['entry_geo_zone'] = $this->language->get('entry_geo_zone');
        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_debug'] = $this->language->get('entry_debug');
        $data['entry_total'] = $this->language->get('entry_total');
        $data['entry_sort_order'] = $this->language->get('entry_sort_order');
        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->error['error_api_key'])) {
            $data['error_api_key'] = $this->error['error_api_key'];
        } else {
            $data['error_api_key'] = '';
        }
        
        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = array(
            'text'      => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', $this->_token, true)
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->extensions_url
        );
        $data['breadcrumbs'][] = array(
            'text'      => $this->language->get('heading_title'),
            'href'      => $this->url->link($this->path, $this->_token, true),
            'separator' => ' :: '
        );

        $data['action'] = $this->url->link($this->path, $this->_token, true);
        $data['cancel'] = $this->extensions_url;

        $keys = array('ipaytotal_hosted_api_key', 'ipaytotal_hosted_total', 'ipaytotal_hosted_order_status_id', 'ipaytotal_hosted_geo_zone_id', 'ipaytotal_hosted_status', 'ipaytotal_hosted_debug', 'ipaytotal_hosted_sort_order');

        foreach ($keys as $key) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } else {
                $data[$key] = $this->config->get($this->prefix . $key);
            }
        }
        
        $this->load->model('localisation/order_status');
        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
        $this->load->model('localisation/geo_zone');
        $data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->_view($this->path, $data));
    }

    private function validate() {
        if (!$this->user->hasPermission('modify', $this->path)) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        if (!$this->request->post['ipaytotal_hosted_api_key']) {
            $this->error['error_api_key'] = $this->language->get('error_api_key');
        }
        return !$this->error;
    }
}