<?php

// Heading
$_['heading_title']      = 'iPayTotal Hosted';
$_['text_ipaytotal_hosted']   = '<a href="https://ipaytotal.com" target="_blank"><img src="view/image/payment/ipaytotal.png" alt="iPayTotal" title="iPayTotal" /></a>';


// Text 
$_['text_extension']  = 'Extensions';
$_['text_payment']    = 'Payment';
$_['text_success']    = 'Success: You have modified iPayTotal details!';
$_['text_edit']       = 'Edit iPayTotal Setting';

// Entry
$_['entry_api_key']        = 'Enter API Key';
$_['entry_order_status'] = 'Order Status:';
$_['entry_total'] = 'Minimum Order Total';
$_['help_total'] = 'The checkout total the order must reach before this payment method becomes active.';

$_['entry_geo_zone']     = 'Geo Zone:'; 
$_['entry_status']       = 'Status:';
$_['entry_sort_order']   = 'Sort Order:';
$_['entry_debug']   = 'Debug:';

// Error 
$_['error_permission']   = 'Warning: You do not have permission to modify payment iPayTotal!';
$_['error_api_key']        = 'iPayTotal API Key is Required!';