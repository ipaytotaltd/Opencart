<?php
class ControllerPaymentIpaytotalHosted extends Controller {
    public function _view($route, $data = array()) {
        if (VERSION < '2.2.0.0') {
            $theme = file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/' . $route . '.tpl') ? $this->config->get('config_template') : 'default';
            $route = $theme . '/template/' . $route . '.tpl';
        }
        return $this->load->view($route, $data);
    }
    public function index() {
        $data['button_confirm'] = $this->language->get('button_confirm');
        return $this->_view('payment/ipaytotal_hosted', $data);
    }

    public function success() {
        $prefix = VERSION >= '3.0.0.0' ? 'payment_' : '';
        $this->language->load('payment/ipaytotal_hosted');
        $this->load->model('checkout/order');
        $order_id = isset($this->request->get['sulte_apt_no']) ? $this->request->get['sulte_apt_no'] : 0;
        if ($order_id) {
            $txn_id = isset($this->request->get['order_id']) ? $this->request->get['order_id'] : 0;
            $comment = sprintf($this->language->get('success_comment'), $txn_id);
            $this->model_checkout_order->addOrderHistory($order_id, $this->config->get($prefix . 'ipaytotal_hosted_order_status_id'), $comment, true);
            $redirect = $this->url->link('checkout/success');
        } else {
            $this->session->data['error'] = $this->language->get('error_payment_failed');
            $redirect = $this->url->link('checkout/checkout');
        }
        $this->response->redirect($redirect);
    }
    
    public function failed() {
        $this->language->load('payment/ipaytotal_hosted');
        $message = isset($this->request->get['message']) && $this->request->get['message'] ? $this->request->get['message'] : $this->language->get('error_payment_failed');
        $this->session->data['error'] = $message;
        $redirect = $this->url->link('checkout/checkout');
        $this->response->redirect($redirect);
    }

    public function response() {
        $status = !empty($this->request->get['response_url']) ? $this->request->get['message'] : 'fail';
        if ($status == 'success') {
            $this->success();
        } else {
            $this->failed();
        }
    }
    
    public function confirm() {
        $prefix = VERSION >= '3.0.0.0' ? 'payment_' : '';
        $json = array();
        $this->language->load('payment/ipaytotal_hosted');
        $this->load->model('checkout/order');
        $this->load->model('localisation/zone');

        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
        if ($order_info['payment_iso_code_2'] == 'US') {
            $zone = $this->model_localisation_zone->getZone($order_info['payment_zone_id']);
            $payment_state = $zone['code'];
        } else {
            $payment_state = $order_info['payment_zone'] ? $order_info['payment_zone'] : $order_info['shipping_zone'];
        }


        $url_success = $this->url->link('payment/ipaytotal_hosted/success');
        $url_fail = $this->url->link('payment/ipaytotal_hosted/failed');
        $url_response = $this->url->link('extension/payment/ipaytotal_hosted/response');
        $url = 'https://ipaytotal.solutions/api/hosted-pay/payment-request';

        $data = array();
        $data['api_key'] = $this->config->get($prefix . 'ipaytotal_hosted_api_key');
        $data['first_name'] =$order_info['payment_firstname'];
        $data['last_name'] = $order_info['payment_lastname'];
        $data['address'] = $order_info['payment_address_1'];
        $data['country'] = $order_info['payment_iso_code_2'];
        $data['state'] = $payment_state;
        $data['city'] = $order_info['payment_city'];
        $data['zip'] = $order_info['payment_postcode'];
        $data['ip_address'] = $this->request->server['REMOTE_ADDR'];
        $data['email'] = $order_info['email'];
        if ($order_info['telephone']) {
            $data['phone_no'] = $order_info['telephone'];
        }

        $data['amount'] = $this->currency->format($order_info['total'], $this->session->data['currency'], false, false);
        $data['currency'] = $order_info['currency_code'];
        $data['sulte_apt_no'] = $this->session->data['order_id'];
        $data['redirect_url_success'] = $url_success;
        $data['redirect_url_fail'] = $url_fail;
        $data['response_url'] = $url_response;
        
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HTTPHEADER,[
            'Content-Type: application/json'
        ]);
        $response = curl_exec($curl);

        if (curl_error($curl)) {
            $json['error'] = 'CURL ERROR: ' . curl_errno($curl) . '::' . curl_error($curl);
            if ($this->config->get($prefix . 'ipaytotal_hosted_debug')) {
                $this->log->write('iPayTotal CURL ERROR: ' . curl_errno($curl) . '::' . curl_error($curl));
            }
        } elseif ($response) {
            $result = json_decode($response, true);
            if ($result && isset($result['status'])) {
                if ($result['status'] == 'success') {
                    $json['redirect'] = $result['payment_redirect_url'];
                } else {
                    if (isset($result['error']) && is_array($result['error'])) {
                        $error = '';
                        foreach ($result['error'] as $each) {
                           $error .= ($error ? ', ' : '') . (is_array($each) ? implode(',', $each) : $each);
                        }
                    } else {
                        $error = $this->language->get('error_payment_failed');
                    }
                    $json['error'] = $error;
                }
            } else {
                $json['error'] = $this->language->get('error_payment_failed');
            }
        } else {
           $json['error'] = $this->language->get('error_payment_failed'); 
        }
        curl_close($curl);
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
}