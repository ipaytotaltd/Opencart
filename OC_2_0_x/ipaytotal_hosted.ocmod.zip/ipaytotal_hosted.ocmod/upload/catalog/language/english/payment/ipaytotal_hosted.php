<?php
// Text
$_['text_title'] = 'iPayTotal';
$_['button_confirm'] = 'Complete Your Payment';

//Error & Success
$_['success_comment'] = 'Payment Processed by iPayTotal (#%s)';
$_['error_payment_failed'] = 'Sorry, Payment was not processed successfully.';