<?php

class ControllerExtensionPaymentIpayTotal extends Controller {

    public function index() {
        $this->language->load('extension/payment/ipaytotal');
        $this->load->model('checkout/order');
        
        $data['text_credit_card'] = $this->language->get('text_credit_card');
        $data['entry_cc_select'] = $this->language->get('entry_cc_select');
        $data['entry_cc_type'] = $this->language->get('entry_cc_type');
        $data['entry_cc_owner'] = $this->language->get('entry_cc_owner');
        $data['entry_cc_number'] = $this->language->get('entry_cc_number');
        $data['entry_cc_expire_date'] = $this->language->get('entry_cc_expire_date');
        $data['entry_cc_cvv2'] = $this->language->get('entry_cc_cvv2');
        $data['entry_cc_amex'] = $this->language->get('entry_cc_amex');
        $data['entry_cc_visa'] = $this->language->get('entry_cc_visa');
        $data['entry_cc_master'] = $this->language->get('entry_cc_master');
        $data['entry_cc_discover'] = $this->language->get('entry_cc_discover');

        $data['button_confirm'] = $this->language->get('button_confirm');

        $data['months'] = array();

        for ($i = 1; $i <= 12; $i++) {
            $data['months'][] = array(
                'text'  => strftime('%B', mktime(0, 0, 0, $i, 1, 2000)),
                'value' => sprintf('%02d', $i)
            );
        }

        $today = getdate();

        $data['year_expire'] = array();

        for ($i = $today['year']; $i < $today['year'] + 11; $i++) {
            $data['year_expire'][] = array(
                'text'  => strftime('%Y', mktime(0, 0, 0, 1, 1, $i)),
                'value' => strftime('%Y', mktime(0, 0, 0, 1, 1, $i))
            );
        }
        return $this->load->view('extension/payment/ipaytotal', $data);
    }
    
    
   public function confirm() {
        $json = array();
        $url = 'https://ipaytotal.solutions/api/transaction';
        $this->language->load('extension/payment/ipaytotal');
        $this->load->model('checkout/order');
        $this->load->model('localisation/zone');

        if (!$this->request->post['cc_owner']) {
           $json['error'] = $this->language->get('error_cc_name');
        } else if (!$this->request->post['cc_type']) {
           $json['error'] = $this->language->get('error_cc_type');
        } else if (!$this->request->post['cc_number']) {
           $json['error'] = $this->language->get('error_cc_number');
        } else if (!$this->request->post['cc_expire_date_month'] || !$this->request->post['cc_expire_date_year']) {
           $json['error'] = $this->language->get('error_cc_expire');
        } else if (!$this->request->post['cc_cvv2']) {
           $json['error'] = $this->language->get('error_cc_cvv');
        }

        if (!isset($json['error'])) {
            $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
            $payment_zone_info = $this->model_localisation_zone->getZone($order_info['payment_zone_id']);
            $payment_state = $order_info['payment_iso_code_2']== 'US' ? $payment_zone_info['code'] : $order_info['payment_zone'];
            if ($order_info['shipping_method']) {
                $shipping_zone_info = $this->model_localisation_zone->getZone($order_info['shipping_zone_id']);
                $shipping_state = $order_info['shipping_iso_code_2']== 'US' ? $shipping_zone_info['code'] : $order_info['shipping_zone'];
            } else {
                $shipping_state = $payment_state;
            }

            $data = array();
            $data['api_key'] = $this->config->get('ipaytotal_api_key');
            $data['card_type'] = $this->request->post['cc_type'];
            $data['card_no'] = str_replace(' ', '', $this->request->post['cc_number']);
            $data['ccExpiryMonth'] = $this->request->post['cc_expire_date_month'];
            $data['ccExpiryYear'] = $this->request->post['cc_expire_date_year'];
            $data['cvvNumber'] = $this->request->post['cc_cvv2'];
            $data['amount'] = $this->currency->format($order_info['total'], $this->session->data['currency'], false, false);
            $data['currency'] = $this->session->data['currency'];

            $data['first_name'] =$order_info['payment_firstname'];
            $data['last_name'] = $order_info['payment_lastname'];
            $data['address'] = $order_info['payment_address_1'];
            $data['country'] = $order_info['payment_iso_code_2'];
            $data['city'] = $order_info['payment_city'];
            $data['zip'] = $order_info['payment_postcode'];
            $data['ip_address'] = $this->request->server['REMOTE_ADDR'];
            $data['email'] = $order_info['email'];
            $data['state'] = $payment_state;
            if ($order_info['payment_address_2']) {
                $data['sulte_apt_no'] = $order_info['payment_address_2'];
            } 
            if ($order_info['telephone']) {
                $data['phone_no'] = $order_info['telephone'];
            }

            /* Customer Shipping Address Fields */
            $data['shipping_first_name'] = $order_info['shipping_method'] ? $order_info['shipping_firstname'] : $order_info['payment_firstname'];
            $data['shipping_last_name'] = $order_info['shipping_method'] ? $order_info['shipping_lastname'] : $order_info['payment_lastname'];
            $data['shipping_country'] = $order_info['shipping_method'] ? $order_info['shipping_iso_code_2'] : $order_info['payment_iso_code_2'];
            $data['shipping_city'] = $order_info['shipping_method'] ? $order_info['shipping_city'] : $order_info['payment_city'];
            $data['shipping_state'] = $shipping_state;

            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_HTTPHEADER,[
                'Content-Type: application/json'
            ]);
            $response = curl_exec($curl);

            if (curl_error($curl)) {
                $json['error'] = 'CURL ERROR: ' . curl_errno($curl) . '::' . curl_error($curl);
                if ($this->config->get('ipaytotal_debug')) {
                    $this->log->write('iPayTotal CURL ERROR: ' . curl_errno($curl) . '::' . curl_error($curl));
                }
            } elseif ($response) {
                $result = json_decode($response);
                if ($result && is_object($result)) {
                    if ($result->status == 'success') {
                        $comment = sprintf($this->language->get('success_comment'), $result->order_id);
                        $this->model_checkout_order->addOrderHistory($this->session->data['order_id'], $this->config->get('ipaytotal_order_status_id'), $comment);
                        $json['redirect'] = $this->url->link('checkout/success', '', true);
                    } else {
                        $json['error'] = property_exists($result, 'message') ? $result->message : $this->language->get('error_payment_failed');
                    }
                } else {
                   $json['error'] = $this->language->get('error_payment_failed');
                }
                if ($this->config->get('ipaytotal_debug')) {
                    $this->log->write('iPayTotal Response: ' . $response);
                }
            }
            curl_close($curl);
        }
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
}